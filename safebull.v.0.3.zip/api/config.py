
import os

postgresql = os.environ.get("db_conn_str")