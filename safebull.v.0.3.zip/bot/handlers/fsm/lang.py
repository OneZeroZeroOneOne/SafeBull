
from aiogram.dispatcher.filters.state import State, StatesGroup


class SelectLang(StatesGroup):
    select_lang = State() 