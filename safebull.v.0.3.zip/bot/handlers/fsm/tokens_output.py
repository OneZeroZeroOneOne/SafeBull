
from aiogram.dispatcher.filters.state import State, StatesGroup


class TokensOutputForm(StatesGroup):
    set_count = State()

    
